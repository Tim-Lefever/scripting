# Write your solution in this file
import re


with open("input.txt") as file:
    for str in file:
        print('\n'.join(line.strip() for line in re.findall(r'.{1,40}(?:\s+|$)', str)))