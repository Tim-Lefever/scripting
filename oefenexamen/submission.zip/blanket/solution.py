from encodings import utf_8
import sys, csv, json, math, datetime
import datetime
from statistics import mean
# Write your solution in this file

dict = {}

with open("input.txt") as file:
    dict = json.load(file)


array = [[date, mean(dict[date])] for date in dict]


array.sort(key=lambda x: datetime.datetime.strptime(x[0], '%d/%m/%Y'))

for date in array:
    print(date[1])